<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>BVRIT Hyderabad College Of Engineering For Women</title>
    <div id="divNews" style="color:Blue"><marquee scrolldelay='80' truespeed='truespeed' >*** Welcome to BVRITH & SVES Family ***</marquee></div>

    <style>
        /* Style for the header */
        header {
            display: flex;
            align-items: center;
            padding: 20px 30px;
            background-color: #f0f0f0;
        }

        /* Style for the logo */
        .logo {
            width: 120px;
            height: auto;
        }

        /* Style for the college name */
        .college-name {
            font-size: 24px;
            font-weight: bold;
            margin-left: 100px;
        }

        /* Style for the main content */
        .main-content {
            text-align: center;
            margin-top: 50px;
        }

        /* Style for the login buttons */
        .login-buttons {
            text-align: center;
            margin-top: 20px;
        }

        .login-button {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            font-size: 25px; /* Reduced font size */
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 10px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <header>
        <img src="logo.png" alt="College Logo" class="logo">
        <span class="college-name"><h2>BVRIT Hyderabad College Of Engineering For Women</h2></span>
    </header>

    <div class="main-content">
        <div class="login-buttons">
            <a href="http://localhost/online-course-registration/Online%20Course%20Registration/admin/admin_login.php" class="login-button">Login as Admin</a>
            <br>
            <a href="http://localhost/online-course-registration/Online%20Course%20Registration/student/student_login.php" class="login-button">Login as Student</a>
            <br>
            <a href="http://localhost/online-course-registration/Online%20Course%20Registration/parent_approval.php" class="login-button">Parent Approval</a>

        </div>
    </div>
</body>

</html>
