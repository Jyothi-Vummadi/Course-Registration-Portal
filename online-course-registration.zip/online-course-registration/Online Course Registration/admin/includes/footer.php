<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; <!--2020 Online Course Registration-->
                </div>

            </div>
        </div>
    </footer>

    <style> .col-md-12{text-align: center;} </style>
