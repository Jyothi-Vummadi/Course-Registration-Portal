<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0) {
    header('location:index.php');
} else {
    if(isset($_POST['submit'])) {
        $selectedCounselor = $_POST["selectedCounselor"];
        if($selectedCounselor != "") {
            $_SESSION['selectedCounselor'] = $selectedCounselor;
        }
    }
    if (isset($_POST['approve'])) {
        $entryId = $_POST['entry_id'];
        // Update the 'counselor' column in the database
        $query = "UPDATE courseenrolls SET counselor = 1 WHERE studentRegno = '$entryId'";
        $result = mysqli_query($bd, $query);
        if($result)
        {
        $_SESSION['msg']="Approved Successfully !!";
        }
        else
        {
        $_SESSION['msg']="Error : Could not approve";
        }
    }
    
?>



<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Admin | Student Registration</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
    <?php include('includes/header.php');?>
    <?php if($_SESSION['alogin']!="") {
        include('includes/menubar.php');
    } ?>

    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-head-line">Counselor Approval</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="panel panel-default"style="width: 130%;">
                        <div class="panel-heading" >
                            Counselor Approval
                        </div>
                        <font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>

                        <div class="panel-body">
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                <label for="selectedCounselor" placeholder="Select Counselor">Counselor:</label>
                                <select name="selectedCounselor">
                                    <option value="">Select Counselor</option>
                                    <?php
                                    $resultCounselors = mysqli_query($bd, "select CName from counselor;");
                                    while ($row = $resultCounselors->fetch_assoc()) {
                                        $counselor = $row['CName'];
                                        $selected = ($counselor == $_SESSION['selectedCounselor']) ? 'selected' : '';
                                        echo "<option value=\"$counselor\" $selected>$counselor</option>";
                                    }
                                    ?>
                                </select>
                                <br>
                                <div align='center'>
                                    <input type="submit" name="submit" value="Show Students">
                                    <br><br>
                                </div>
                            </form>
                            <?php
                            if(isset($_SESSION['selectedCounselor']) && $_SESSION['selectedCounselor'] != '') {
                                $selectedCounselor = $_SESSION['selectedCounselor'];
                                $query = "SELECT
                                ce.course AS courname,
                                ce.enrollDate AS edate,
                                ce.semester AS sem,
                                st.studentName AS sname,
                                st.StudentRegno AS sregno
                                FROM
                                courseenrolls ce
                                JOIN students st ON st.StudentRegno = ce.studentRegno
                                WHERE
                                ce.counselor = 0 AND st.CName = '$selectedCounselor';";


                                $resultStudents = mysqli_query($bd, $query);
                                if(mysqli_num_rows($resultStudents) > 0) {
                                    ?>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            Students under <?php echo $selectedCounselor; ?>
                                        </div>
                                        <div class="panel-body">
                                            <div class="table-bordered">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Reg No.</th>
                                                            <th>Student Name</th>
                                                            <th>Course</th>
                                                            <th>Semester</th>
                                                            <th>Enrollment Date</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $cnt = 1;
                                                        while($row = mysqli_fetch_assoc($resultStudents)) {
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $cnt;?></td>
                                                                <td><?php echo htmlentities($row['sregno']);?></td>
                                                                <td><?php echo htmlentities($row['sname']);?></td>
                                                                <td><?php echo htmlentities($row['courname']);?></td>
                                                                <td><?php echo htmlentities($row['sem']);?></td>
                                                                <td><?php echo htmlentities($row['edate']);?></td>
                                                                <td>
                                                                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                                                <input type="hidden" name="entry_id" value="<?php echo htmlentities($row['sregno']);?>">
                                                                <input type="submit" name="approve" value="Approve">
                                                        </td>
                                                            </form>

                                                            </tr>
                                                            <?php 
                                                            $cnt++;
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                } else {
                                    echo "<p>No students found under $selectedCounselor.</p>";
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.11.1.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script>
    function userAvailability() {
        $("#loaderIcon").show();
        jQuery.ajax({
            url: "check_availability.php",
            data:'regno='+$("#studentregno").val(),
            type: "POST",
            success:function(data){
                $("#user-availability-status1").html(data);
                $("#loaderIcon").hide();
            },
            error:function (){}
        });
    }
    </script>
    <!-- <script>
    function approveEntry(entryId) {
        // AJAX request to update the database
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Handle the response, if needed
                console.log(xhr.responseText);
            }
        };
        xhr.send('entry_id=' + entryId);
    }
</script> -->
</body>
</html>
<?php } ?>
